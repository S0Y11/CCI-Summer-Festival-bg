import './style.css'

import * as THREE from 'three'

let oscValues = {
  alpha: 0,
  beta: 0,
  theta: 0
};
// scene setup (cameera, lighting, roughness and metallic material idk if this will mess with the colour changing i dont think it will!!)
const options = {
  width: window.innerWidth,
  height: window.innerHeight
} 

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(60, options.width/ options.height, 0.1,1000);
camera.position.set (0,10,20);
camera.lookAt(scene.position);

const clock = new THREE.Clock();

const sphereGeometry =  new THREE.SphereGeometry(0.5,16,16);
const sphereMaterial = new THREE.MeshStandardMaterial({metalness:0.9,roughness:0.1});


const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.z = 10;
directionalLight.position.x = 10;
directionalLight.position.y = 10;
scene.add(directionalLight);


const renderer = new THREE.WebGLRenderer();
renderer.setSize(options.width, options.height);
renderer.setPixelRatio(1);
document.body.appendChild(renderer.domElement);

const gridSize = 100;
const spacing = 2.5;
const spheres = [];
// grid 
for(let x = 0; x < gridSize; x++) {
  for (let z = 0; z< gridSize; z++){
    const sphere = new THREE.Mesh(sphereGeometry,sphereMaterial);
    sphere.position.x = (x - gridSize/2) * spacing;
    sphere.position.z = (z - gridSize/2) * spacing;
    scene.add(sphere);
    spheres.push({sphere,x,z});
  }
}


function animate(){
  requestAnimationFrame(animate);
const t = clock.getElapsedTime();
// should change with the mapped osc values, is set to grey when nothing is detected 
let waveSpeed = 4;
let targetColor = new THREE.Color();

  const hasValidOsc = oscValues &&
    typeof oscValues.alpha === 'number' &&
    typeof oscValues.beta === 'number' &&
    typeof oscValues.theta === 'number';

 let state = 'neutral';
if (hasValidOsc){
 if(oscValues.beta> 0.7 &&oscValues.alpha < 0.33){
  state = 'stressed';
 } else if (oscValues.alpha> 0.6 && oscValues.theta > 0.5){
  state = 'calm';
 } else if (oscValues.theta > 0.7){
  state = 'focused' ;
 }
 }

switch (state) {
    case 'stressed':
    waveSpeed = 10;
    targetColor.set('#ff0000');
    break;

    case 'calm':
    waveSpeed = 2;
    targetColor.set('#00ff00');
    break;

    case 'focused':
    waveSpeed = 5;
    targetColor.set('#ff0000');
    break;

    default:
    waveSpeed = 4;
    targetColor.set('#ffffff');
    break;
}

sphereMaterial.color.lerp(targetColor,0.1);

for( const{sphere,x,z} of spheres){
  const wave = Math.sin((x+t*waveSpeed)*0.8) + Math.cos((z + t*waveSpeed) * 0.8);
  sphere.position.y = wave *0.5;
}

  renderer.render(scene, camera); 

}
animate();

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});